
from flask import Flask,render_template,request,session,redirect,flash,url_for,send_file
from flask_migrate import Migrate
from models import db,User,Influencer,Sponsor,Campaign,AdRequest,CampaignRequest
from datetime import datetime
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import io


app =Flask(__name__)
app.secret_key='Ashish'

app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///SocialMedia.sqlite3"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_SILENCE_UBER_WARNING'] = 1
db.init_app(app)
migrate = Migrate(app,db)

# sample_data = [
#     {"u_name":"yash" , "pwd":"1234"}
# ]


# ----------------------LDGIN PAGE--------------------------------

@app.route('/', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if user is None:
            flash("User Not Found, Please register To Continue.")
            return redirect("/")

        if user.password != password:
            flash("Your password or username is wrong, please try again.")
            return redirect("/")
        influ_user = Influencer.query.filter_by(user_id=user.id).first()
        if user.role == "influencer":
            
            if influ_user is None:
                flash("Influencer profile not found.")
                return redirect("/")

            if influ_user.flagged:
                flash("You are flagged and cannot log in.")
                return redirect("/")

            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('influencer_dashboard'))

        elif user.role == "sponser":
            spon_user = Sponsor.query.filter_by(user_id=user.id).first()
            if spon_user is None:
                flash("Sponsor profile not found.")
                return redirect("/")

            if spon_user.flagged:
                flash("You are flagged and cannot log in.")
                return redirect("/")

            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('sponser_PROFILE'))

    return render_template('user_login.html')


# ------------------------------------------------------------------------------


# ===================================Sponsor=====================================



@app.route('/sponsor_reg' , methods = ['GET' , 'POST'])
def sponser_signup():
    if request.method =='POST': 
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        industry = request.form['industry']
        budget = request.form['budget']

        addNew = User(username = username,email = email,password = password,role = "sponser")
        db.session.add(addNew)
        db.session.commit()

        user =User.query.filter_by(username=username).first()
        addNewSponser = Sponsor(name = username,industry=industry,budget=budget,user_id=user.id)
        db.session.add(addNewSponser)
        db.session.commit()
        flash('Registration successfully completed! now,Login From here', 'success')

        # campaign = Campaign.query.filter(Campaign.sponsor_id == user.id).all()
        
        return redirect('/')
    
    return render_template("sponsor_reg.html")




@app.route('/sponser_campaign' , methods = ['GET' , 'POST'])
def sponser_campaign():
    return render_template('sponser_campaign.html')



@app.route('/sponser_PROFILE', methods=['GET', 'POST'])
def sponser_PROFILE():
    username = session.get('username')
    user = User.query.filter_by(username=username).first()
    sponsor = Sponsor.query.filter_by(user_id=user.id).first()

    campaigns = Campaign.query.filter(Campaign.sponsor_id == user.id).all()
    campaign_ids = [campaign.id for campaign in campaigns]
    print(campaign_ids)
    ad_requests = AdRequest.query.join(Campaign).filter(Campaign.sponsor_id == user.id).all()
    campaign_requests = CampaignRequest.query.filter(CampaignRequest.campaign_id.in_(campaign_ids),CampaignRequest.status=='pending').all()
    print(campaign_requests)
    return render_template('/sponser_PROFILE.html', campaigns=campaigns, ad_requests=ad_requests, user=user, campaign_requests=campaign_requests)







@app.route('/sponser_FIND', methods=['GET', 'POST'])
def sponser_FIND():
    min_reach = request.args.get('min_reach', type=int)
    max_reach = request.args.get('max_reach', type=int)

    query = Influencer.query

    if min_reach is not None:
        query = query.filter(Influencer.reach >= min_reach)
    if max_reach is not None:
        query = query.filter(Influencer.reach <= max_reach)

    influencers = query.all()

    return render_template('sponser_FIND.html', influencers=influencers)

# ==============================Influencer=====================================




@app.route('/influencer_signup', methods=['GET', 'POST'])
def influencer_signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        category = request.form['category']
        niche = request.form['niche']
        reach = request.form['reach']

        

        new_user = User(username=username, email=email, password=password, role="influencer")
        db.session.add(new_user)
        db.session.commit()

        user = User.query.filter_by(username=username).first()

        new_influencer = Influencer(name=username, category=category, niche=niche, reach=reach, user_id=user.id)
        db.session.add(new_influencer)
        db.session.commit()
        flash('Registration successfully completed! now,Login From here', 'success')

        session['user_id'] = user.id

        return redirect('/')

    return render_template('influencer_signup.html')

# @app.route('/influencer_Profile')
# def influencer_Profile():
#     user_id = session.get('user_id')
#     if user_id:
#         user = User.query.get(user_id)
#         if user:
#             return render_template('influencer_dash_profile.html', user=user)

#     return redirect('/influencer_signup')



@app.route('/influencer' , methods = ['GET' , 'POST'])
def influencer_reg():
    return render_template('influencer_reg.html')



from sqlalchemy import or_

@app.route('/influencer_dashboard', methods=['GET', 'POST'])
def influencer_dashboard():
    username = session.get('username')
    user = User.query.filter_by(username=username).first()

    if user:
        influencer = Influencer.query.filter_by(user_id=user.id).first()
        if influencer:
            # Filter ad requests by influencer_id or where influencer_id is NULL
            ad_requests = AdRequest.query.filter(
                or_(AdRequest.influencer_id == influencer.id, AdRequest.influencer_id.is_(None))
            ).all()
            campaign_requests = CampaignRequest.query.filter_by(influencer_id=influencer.id).all()
            
            return render_template('influencer_dash_profile.html', user=user, 
                                   influencer=influencer,
                                   ad_requests=ad_requests,
                                   campaign_requests=campaign_requests)
        else:
            flash('Influencer profile not found.')
            return redirect(url_for('influencer_signup'))
    else:
        flash('User not found or session expired.')
        return redirect(url_for('influencer_signup'))








@app.route('/accept_ad/<int:ad_id>', methods=['POST'])
def accept_ad(ad_id):
    ad_request = AdRequest.query.get_or_404(ad_id)
    ad_request.status = 'Accepted'
    db.session.commit()
    # flash('Ad request accepted successfully', 'success')
    return redirect(url_for('influencer_dashboard'))


@app.route('/reject_ad/<int:ad_id>', methods=['POST'])
def reject_ad(ad_id):
    ad_request = AdRequest.query.get_or_404(ad_id)
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected successfully', 'danger')
    return redirect(url_for('influencer_dashboard'))

# ------------------------------

@app.route('/influencer_Find', methods=['GET', 'POST'])
def influencer_Find():
    username = session.get('username')
    user = User.query.filter_by(username=username).first()

    if user:
        influencer = Influencer.query.filter_by(user_id=user.id).first()
        if influencer:
            # Get all campaign requests made by this influencer
            requested_campaign_ids = [req.campaign_id for req in CampaignRequest.query.filter_by(influencer_id=influencer.id).all()]
            
            # Filter campaigns that has not been requested by this influencer
            campaigns = Campaign.query.filter(Campaign.visibility == 'public', ~Campaign.id.in_(requested_campaign_ids)).all()
            
            return render_template('influencer_dash_FIND.html', campaigns=campaigns, user_id=user.id)
        else:
            flash('Influencer profile not found.')
            return redirect(url_for('influencer_signup'))
    else:
        flash('User not found or session expired.')
        return redirect(url_for('influencer_signup'))



#------------------------Campaign Requests -------------------------------------------


@app.route('/request_campaign/<int:campaign_id>', methods=['POST'])
def request_campaign(campaign_id):
    user_id = request.form['user_id']
    username = session.get('username')
    user = User.query.filter_by(username=username).first()
    influencer = Influencer.query.filter_by(user_id=user.id).first()
    # Process the request
    campaign_request = CampaignRequest(
        campaign_id=campaign_id,
        influencer_id=influencer.id,
        status='pending'
    )
    db.session.add(campaign_request)
    db.session.commit()
    
    # flash('Campaign request submitted successfully', 'success')
    flash('Campaign request submitted successfully!', 'success')
    return redirect(url_for('influencer_Find'))


@app.route('/accept_campaign_request/<int:request_id>', methods=['POST'])
def accept_campaign_request(request_id):
    campaign_request = CampaignRequest.query.get_or_404(request_id)
    campaign_request.status = 'Accepted'
    db.session.commit()
    flash('Campaign request accepted.', 'success')
    return redirect(url_for('sponser_PROFILE'))

@app.route('/reject_campaign_request/<int:request_id>', methods=['POST'])
def reject_campaign_request(request_id):
    campaign_request = CampaignRequest.query.get_or_404(request_id)
    campaign_request.status = 'Rejected'
    db.session.commit()
    flash('Campaign request rejected.', 'danger')
    return redirect(url_for('sponser_PROFILE'))



@app.route('/cancel_request/<int:request_id>', methods=['POST'])
def cancel_request(request_id):
    campaign_request = CampaignRequest.query.get_or_404(request_id)
    if campaign_request and campaign_request.status.lower() == 'pending':
        db.session.delete(campaign_request)
        db.session.commit()
        flash('Request cancelled successfully.', 'success')
    else:
        flash('Request could not be cancelled.', 'error')
    
    return redirect(url_for('influencer_dashboard'))






# =============================admin=============================================

@app.route('/admin_Find' , methods = ['GET' , 'POST'])
def admin_Find():
    campaigns = Campaign.query.all()

    ad_requests = AdRequest.query.all()
    influencer = Influencer.query.all()
    sponsor = Sponsor.query.all()
    flagged_influencers = Influencer.query.filter_by(flagged=True).all()
    flagged_sponsor = Sponsor.query.filter_by(flagged=True).all()

    sponsor = Sponsor.query.all()
    

    return render_template('admin_dash_Find.html', campaigns=campaigns,
                            ad_requests=ad_requests,influencer=influencer,sponsor=sponsor,
                            flagged_influencers=flagged_influencers,flagged_sponsor=flagged_sponsor)




@app.route('/flag_sponsor/<int:sponsor_id>', methods=['POST'])
def flag_sponsor(sponsor_id):
    sponsor = Sponsor.query.get(sponsor_id)
    if sponsor:
        sponsor.flagged = not sponsor.flagged
        db.session.commit()
    return redirect(url_for('admin_Find'))




@app.route('/flag_influencer/<int:influencer_id>', methods=['POST'])
def flag_influencer(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    influencer.flagged = not influencer.flagged  # Toggle the flagged status
    db.session.commit()
    return redirect(url_for('admin_Find'))





@app.route('/admin_info', methods=['GET', 'POST'])
def admin_info():
    total_campaign = Campaign.query.count()
    total_Ad_Requests = AdRequest.query.count()
    total_influencers = Influencer.query.count()
    total_sponsors = Sponsor.query.count()

    recent_campaign = Campaign.query.order_by(Campaign.start_date.desc()).first()
    recent_influencer = Influencer.query.order_by(Influencer.name.desc()).first()
    recent_sponsor = Sponsor.query.order_by(Sponsor.name.desc()).first()

 # Query to get the top influencer by the number of ad requests
    top_influencer = db.session.query(
        Influencer.name, db.func.count(AdRequest.id).label('ad_request_count')
    ).join(AdRequest).group_by(Influencer.id).order_by(db.func.count(AdRequest.id).desc()).first()

    top_influencer_name = top_influencer.name if top_influencer else 'No influencer data'

   

    return render_template('admin_dash_info.html',
                           total_campaign=total_campaign,
                           total_Ad_Requests=total_Ad_Requests,
                           total_influencers=total_influencers,
                           total_sponsors=total_sponsors,
                           recent_campaign=recent_campaign,
                           recent_influencer=recent_influencer,
                           recent_sponsor=recent_sponsor,
                           top_influencer_name=top_influencer_name)





@app.route('/plot.png')
def bar_graph():
    # Example data
    x = ['Campaigns', 'Ad Requests', 'Influencers', 'Sponsors']
    y = [
        Campaign.query.count(),
        AdRequest.query.count(),
        Influencer.query.filter_by(flagged=False).count(),  # Exclude flagged influencers
        Sponsor.query.count()
    ]

    fig, ax = plt.subplots(figsize=(12, 10))
    ax.bar(x, y, color=['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'])
    plt.title('Bar Graph')
    plt.ylabel('Count')

    output = io.BytesIO()
    plt.savefig(output, format='png')
    output.seek(0)
    return send_file(output, mimetype='image/png')

    




@app.route('/admin_login', methods=['GET', 'POST'])
def admin():

    total_campaign = Campaign.query.count()
    total_Ad_Requests = AdRequest.query.count()
    total_influencers = Influencer.query.count()
    total_sponsors = Sponsor.query.count()

    recent_campaign = Campaign.query.order_by(Campaign.start_date.desc()).first()
    recent_influencer = Influencer.query.order_by(Influencer.name.desc()).first()
    recent_sponsor = Sponsor.query.order_by(Sponsor.name.desc()).first()

    # Query to get the top influencer by the number of ad requests
    top_influencer = db.session.query(
        Influencer.name, db.func.count(AdRequest.id).label('ad_request_count')
    ).join(AdRequest).group_by(Influencer.id).order_by(db.func.count(AdRequest.id).desc()).first()

    top_influencer_name = top_influencer.name if top_influencer else 'No influencer data'



    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        campaigns = Campaign.query.all()
        ad_requests = AdRequest.query.all() 

        if user is None:
            flash("You are not admin.")
            return redirect("/admin")
        
        elif user.username != username or user.password != password:
            flash("Your password or username is wrong, please try again")
            return redirect("/admin")
        
        elif user.username == username and user.password == password and user.role == "admin":
            session['logged_in'] = True
            session['username'] = username
            return render_template("admin_dash_info.html", user=user,
                                ad_requests=ad_requests,campaigns=campaigns,
                                total_campaign=total_campaign,
                                total_Ad_Requests=total_Ad_Requests,
                                total_influencers=total_influencers,
                                total_sponsors=total_sponsors,
                                recent_campaign=recent_campaign,
                                recent_influencer=recent_influencer,
                                recent_sponsor=recent_sponsor,
                                top_influencer_name=top_influencer_name)
        

    return render_template('admin_login.html')

# ===============New Campaign=============================

@app.route('/new_campaign_form', methods=['GET', 'POST'])
def New_campain_form():
    return render_template("new_campaign.html")


# --------------------------------------------------



@app.route('/new_campaign', methods=['POST'])
def New_campain():
    if request.method=='POST':
        name = request.form['cname']
        description = request.form['desc']
        start_date = request.form['s_date']
        end_date = request.form['e_date']
        budget = request.form['budget']
        visibility = request.form['vis']
        goal = request.form['goal']
        username = session.get('username')
        user = User.query.filter_by(username = username).first()

        start_date = datetime.strptime(start_date, '%Y-%m-%dT%H:%M')
        end_date = datetime.strptime(end_date, '%Y-%m-%dT%H:%M')

        addNew = Campaign(sponsor_id=user.id,name = name,
                          description=description,start_date=start_date,
                          end_date=end_date,budget=budget,visibility=visibility,goals=goal)
        db.session.add(addNew)
        db.session.commit()
        flash('Campaign added successfully!', 'success')
        return redirect('/sponser_PROFILE')
    


# ==================Update Campaign========================



@app.route('/update_campaign/<int:id>',methods=['GET','POST'])
def Update_campaign(id):
    if request.method=='POST':
        campaign = Campaign.query.filter_by(id=id).first()
        name = request.form['cname']
        description = request.form['desc']
        start_date = request.form['s_date']
        end_date = request.form['e_date']
        budget = request.form['budget']
        visibility = request.form['vis']
        goal = request.form['goal']
        
        username = session.get('username')
        user = User.query.filter_by(username = username).first()

        if start_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%dT%H:%M')
            campaign.start_date = start_date
        if end_date:
            end_date = datetime.strptime(end_date, '%Y-%m-%dT%H:%M')
            campaign.end_date = end_date
        
        campaign.name = name
        campaign.description = description
        campaign.budget = budget
        campaign.visibility = visibility
        campaign.goals = goal

        db.session.commit()
        flash('Campaign updated successfully!', 'success') 
        
        return redirect('/sponser_PROFILE')


# ============delete campaign=========================



@app.route('/delete_campaign/<int:id>')
def delete_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    db.session.delete(campaign)
    db.session.commit()
    flash("Campaign Successfully deleted!!", "success")
    

    return redirect('/sponser_PROFILE')


@app.route('/campaign_show', methods=['GET'])
def Campaign_show():
    return render_template("campaign_show.html")




#  ==============================Ad Request=============================================


@app.route('/new_ad_request_form', methods=['GET','POST'])
def ad_request():
    username = session.get('username')
    user = User.query.filter_by(username=username).first()
    # sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    campaigns = Campaign.query.filter_by(visibility='private',sponsor_id=user.id).all()

    influencers = Influencer.query.all()
    return render_template("new_ad_request.html",campaigns=campaigns,influencers=influencers,user=user)

# ------------------------------------------------------
@app.route('/new_ad_request', methods=['GET','POST'])
def New_ad_request():
    if request.method=='POST':
        Campaign_id=request.form['campaign_id']
        influencer_id=request.form['influencer_id']
        message = request.form['messages']
        requirement = request.form['requirements']
        payment_amount = request.form['payment_amount']
        status = request.form['status']
        

        addNew = AdRequest(campaign_id=Campaign_id,influencer_id=influencer_id
                          ,messages=message,requirements=requirement,payment_amount=payment_amount,status=status)
        db.session.add(addNew)
        db.session.commit()
        return redirect('/sponser_PROFILE')
    return render_template("/new_ad_request.html")
        
      



# ============Edit Ad Request=========================


@app.route('/update_adrequest/<int:id>', methods=['GET', 'POST'])
def Update_adrequest(id):
    adrequest = AdRequest.query.get_or_404(id)
    
    # Check if ad request status is  != Pending
    if adrequest.status != 'Pending':
        return redirect('/sponser_PROFILE')
    
    if request.method == 'POST':
        campaign_id = request.form['campaign_id']
        influencer_id = request.form['influencer_id']
        message = request.form['messages']
        requirement = request.form['requirements']
        payment_amount = request.form['payment_amount']
        status = request.form['status']
        
        # Update adrequest 
        adrequest.campaign_id = campaign_id
        adrequest.influencer_id = influencer_id
        adrequest.messages = message
        adrequest.requirements = requirement
        adrequest.payment_amount = payment_amount
        adrequest.status = status
        
        db.session.commit()
        flash('Ad request updated successfully!', 'success')

        return redirect('/sponser_PROFILE')


# ============delete Ad Request=========================


@app.route('/delete_AdRequest/<int:id>')
def delete_adrequest(id):
    adrequest = AdRequest.query.get_or_404(id)
    db.session.delete(adrequest)
    db.session.commit()
    flash("AdRequest Successfully deleted!!", "success")
    
    return redirect('/sponser_PROFILE')


# ++++++++++++++++++public ad request++++++++++++++++++++=


@app.route('/public_ad_request_form', methods=['GET', 'POST'])
def public_ad_request():
    if request.method == 'POST':
        campaign_id = request.form.get('campaign_id')
        message = request.form.get('messages')
        requirement = request.form.get('requirements')
        payment_amount = request.form.get('payment_amount')
        status = request.form.get('status')
        
        # Retrieve all influencers from the database
        all_influencers = Influencer.query.all()
        
        for influencer in all_influencers:
            addNew = AdRequest(
                campaign_id=campaign_id,
                influencer_id=influencer.id,
                messages=message,
                requirements=requirement,
                payment_amount=payment_amount,
                status=status
            )
            db.session.add(addNew)
        
        db.session.commit()

        flash('Public campaign request added successfully for all influencers!', 'success')
        return redirect('/sponser_PROFILE')

    username = session.get('username')
    user = User.query.filter_by(username=username).first()
    # sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    campaigns = Campaign.query.filter_by(visibility='public',sponsor_id=user.id).all()
    influencers = Influencer.query.all()
    return render_template("public_ad_request.html", campaigns=campaigns, influencers=influencers, user=user)










# ----------------------------Admin Search--------------------------------------------
@app.route('/admin_search')
def admin_search():
    srch_word = request.args.get('srch_word')
    campaigns = Campaign.query.all()
    ad_requests = AdRequest.query.all()
    influencer = Influencer.query.all()
    sponsor = Sponsor.query.all()
    
    filtered_campaigns = [campaign for campaign in campaigns 
                          if srch_word.lower() in campaign.name.lower()
                          or srch_word.lower() in campaign.description.lower()]
    
    filtered_influencer = [inf for inf in influencer 
                          if srch_word.lower() in inf.name.lower()
                          or srch_word.lower() in inf.category.lower()]
    
    
    filtered_sponsor = [sop for sop in sponsor 
                          if srch_word.lower() in sop.name.lower()
                          or srch_word.lower() in sop.industry.lower()]
    
    try:
        srch_word_int = int(srch_word)
    except ValueError:
        srch_word_int = None
    
    filtered_adrequest = [ad for ad in ad_requests 
                          if srch_word.lower() in ad.messages.lower()
                          or (srch_word_int is not None and srch_word_int == ad.campaign_id)
                          or (srch_word_int is not None and srch_word_int == ad.influencer_id)]
    

    return render_template('admin_search.html', srch_word=srch_word,
                            filtered_campaigns=filtered_campaigns,
                            filtered_adrequest=filtered_adrequest,
                            filtered_influencer=filtered_influencer,
                            filtered_sponsor=filtered_sponsor)


# -----------------------------------influencer search-----------------------------------------
@app.route('/influencer_search')
def influencer_search():
    srch_word = request.args.get('srch_word', '').lower()  
    campaigns = Campaign.query.all()

    filtered_campaigns = [
        campaign for campaign in campaigns 
        if srch_word in (campaign.name.lower() if campaign.name else '') or 
           srch_word in (campaign.visibility.lower() if campaign.visibility else '')]

    return render_template('influencer_search.html', srch_word=srch_word,
                            filtered_campaigns=filtered_campaigns)





# -----------------------------------Sponsor search-----------------------------------------

@app.route('/sponser_search')
def sponser_search():
    srch_word = request.args.get('srch_word')
    filtered_influencers = Influencer.query.filter(
                            (Influencer.niche.ilike(f'%{srch_word}%')) |
                              (Influencer.name.ilike(f'%{srch_word}%'))).all()

    return render_template('sponser_search.html', srch_word=srch_word,
                           filtered_influencers=filtered_influencers)






@app.route('/sponser_filter', methods=['GET'])
def sponser_filter():
    influencers = Influencer.query.all()
    min_reach = request.args.get('min_reach', type=int)
    max_reach = request.args.get('max_reach', type=int)
    
    # Filter influencers based on the reach criteria
    filtered_influencers = [
        inf for inf in influencers 
        if (min_reach is None or inf.reach >= min_reach) and 
           (max_reach is None or inf.reach <= max_reach)
    ]
    
    return render_template('sponser_filter.html', influencers=filtered_influencers)



# ------------------------------------------------------------------------






if __name__ == '__main__':
    app.debug = True
    app.run()

